class MyRoutes {
  static String loginRoute = '/login';
  static String homeRoute = '/home';
  static String homeRoute2 = '/home2';
  static String escalationRoute = '/esclationchart';
  static String adminchartRoute = '/adminchart';
  static String registrationRoute = '/registration';
}
