import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_development_123/utils/routes.dart';
import '../utils/flobalVariables.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
//import 'package:rdsocomplain/homepage.dart';
//import 'package:rdsocomplain/pages/dashboard.dart';
//import 'package:rdsocomplain/pages/registration.dart';
//import 'package:rdsocomplain/pages/resetpassword.dart';
import 'package:shared_preferences/shared_preferences.dart';
//import 'package:rdsocomplain/pages/otp.dart';
import 'package:crypto/crypto.dart'; //include dependency in pubsec  crypto: ^3.0.2

//import 'demodashboard.dart';

//import http package manually

class LoginPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _LoginPage();
  }
}

class _LoginPage extends State<LoginPage> {
  late String errormsg;
  late bool error, showprogress;
  late String username, password;

  var _username = TextEditingController();
  var _password = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  startLogin() async {
    if (_formKey.currentState!.validate()) {
      String apiurl = "https://hello-259.herokuapp.com/rdso/post-user-api";
      // print(uri);
      // print(username+"    "+password);

      var response = await http.post(Uri.parse(apiurl),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(<String, String>{
            "username": username,
            "password": md5.convert(utf8.encode(password)).toString()
          }));
      print(response.body);
      Map<String, dynamic> output = json.decode(response.body);

      var Name = json.decode(response.body);

      // var response = await http.get(uri);

      if (response.statusCode == 200) {
        print("ENTER HERE");
        final jsonData = jsonDecode(response.body);
        SharedPreferences prefs = await SharedPreferences.getInstance();
        // obtain shared preferences
        await prefs.setString('uniqueid', username);
        await prefs.setString('username', jsonData["name"]);
        await prefs.setString('designation', jsonData["designation"]);
        await prefs.setString('department', jsonData["department"]);
        await prefs.setString('building', jsonData["building"]);
        await prefs.setString('bldg_id', jsonData["bldg_id"]);
        await prefs.setString('dte_id', jsonData["dte_id"]);
        await prefs.setString('address', jsonData["address"]);
        role_no = output["role_id"][0]["role_id"];
        name = Name["user_name"];
        role = output["role_id"][0]["role"];
        fields = output["role_id"][0]["field_id"];

        setState(() {});
        print(role_no);
        print(Name["user_name"]);
        print(output["role_id"][0]["role"]);
        print(output["role_id"][0]["field_id"]);

        // print("login token" + response.toString());
        if (jsonData["error"]) {
          setState(() {
            showprogress = false; //don't show progress indicator
            error = true;
            errormsg = jsonData["message"];
          });
        } else {
          if (jsonData["success"]) {
            setState(() {
              error = false;
              showprogress = false;
            });
            //save the data returned from server
            //and navigate to home page
            // String fullname = jsonData["ipasid"];
            // String ipasid = jsonData["ipasid"];
            // String address = jsondata["address"];
//print(ipasid);

            //user shared preference to save data
            //Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()),
            // Navigator.pushAndRemoveUntil(
            //   context,
            //   MaterialPageRoute(builder: (context) => demodashboard()),
            //   (Route<dynamic> Route) => false,
            // );
            //  Navigator.pushAndRemoveUntil(context,  , (route) => false);
            // Get.toNamed('homepage');

          } else {
            showprogress = false; //don't show progress indicator
            error = true;
            errormsg = "Something went wrong.";
          }
        }
      } else {
        setState(() {
          showprogress = false; //don't show progress indicator
          error = true;
          errormsg = "Error during connecting to server.";
        });
      }
    } else {
      setState(() {
        showprogress = false; //don't show progress indicator
        error = false;
        errormsg = "";
      });
    }
  }
  //     moveToHome(BuildContext context) async {
  //   if (_formKey.currentState!.validate()) {
  //     await Future.delayed(
  //       Duration(seconds: 1),
  //     );
  //     await Navigator.pushNamed(context, MyRoutes.homeRoute);
  //   }
  // }

  @override
  void initState() {
    username = "";
    password = "";
    errormsg = "";
    error = false;
    showprogress = false;

    //_username.text = "defaulttext";
    //_password.text = "defaultpassword";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent
            //color set to transperent or set your own color
            ));

    return Scaffold(
      body: SingleChildScrollView(
          child: Form(
        key: _formKey,
        child: Container(
          constraints:
              BoxConstraints(minHeight: MediaQuery.of(context).size.height
                  //set minimum height equal to 100% of VH
                  ),
          width: MediaQuery.of(context).size.width,
          //make width of outer wrapper to 100%
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Colors.purple.shade400,
                Colors.purple.shade300,
                Colors.purple.shade200,
                Colors.purple.shade100,
              ],
            ),
          ), //show linear gradient background of page

          padding: EdgeInsets.all(20),
          child: Column(children: <Widget>[
            Container(
              margin: EdgeInsets.only(top: 80),
              child: Text(
                "RDSO Log In",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 40,
                    fontWeight: FontWeight.bold),
              ), //title text
            ),
            Container(
              margin: EdgeInsets.only(top: 10),
              child: Text(
                "Sign In using ipasid/uniqueid and Password",
                style: TextStyle(color: Colors.white, fontSize: 15),
              ), //subtitle text
            ),
            Container(
              //show error message here
              margin: EdgeInsets.only(top: 30),
              padding: EdgeInsets.all(10),
              child: error ? errmsg(errormsg) : Container(),
              //if error == true then show error message
              //else set empty container as child
            ),
            Container(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              margin: EdgeInsets.only(top: 10),
              child: TextFormField(
                controller: _username, //set username controller
                style: TextStyle(color: Colors.purple[100], fontSize: 20),
                decoration: myInputDecoration(
                  label: "Username",
                  icon: Icons.person,
                ),
                // keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]")),
                  LengthLimitingTextInputFormatter(12)
                ],
                validator: (value) {
                  if (value!.isEmpty) {
                    return "ID cannot be empty";
                  } else if (value.length < 10 || value.length > 12) {
                    return "Uid must be of 10-12 digits";
                  }
                  return null;
                },
                onChanged: (value) {
                  //set username  text on change
                  username = value;
                },
              ),
            ),
            Container(
              padding: EdgeInsets.all(10),
              child: TextFormField(
                controller: _password, //set password controller
                style: TextStyle(color: Colors.purple[100], fontSize: 20),
                obscureText: true,
                decoration: myInputDecoration(
                  label: "Password",
                  icon: Icons.lock,
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Password cannot be empty";
                  } else if (value.length < 6) {
                    return "Password length should be atleast 6";
                  }
                  return null;
                },
                onChanged: (value) {
                  // change password text
                  password = value;
                },
              ),
            ),
            // SizedBox(height: 30,),
            Container(
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.only(top: 20),
              child: SizedBox(
                height: 60,
                width: 140,
                // width: double.infinity,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.purple.shade400,
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  // color: Colors.white,
                  child: TextButton(
                    onPressed: () {
                      setState(() {
                        //show progress indicator on click
                        showprogress = true;
                      });
                      startLogin();
                    },
                    style: TextButton.styleFrom(),
                    child: showprogress
                        ? SizedBox(
                            height: 30,
                            width: 30,
                            child: CircularProgressIndicator(
                              backgroundColor: Colors.purple[500],
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.deepPurpleAccent),
                            ),
                          )
                        : Text(
                            "Login",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          ),
                    // if showprogress == true then show progress indicator
                    // else show "LOGIN NOW" text
                    //  colorBrightness: Brightness.dark,
                    //  color: Colors.orange,
                    //  shape: RoundedRectangleBorder(
                    // borderRadius: BorderRadius.circular(30)
                    //button corner radius
                    //      ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              // color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // SizedBox(width: ,)
                  Container(
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(top: 20),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.purple.shade400,
                        border: Border.all(
                          color: Colors.black,
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextButton(
                          onPressed: () {
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => Register()));
                            // //action on tap
                          },
                          child: Text(
                            "Registration",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          )),
                    ),
                  ),
                  // SizedBox(height: 30,),
                  Container(
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(top: 20),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.purple.shade400,
                        border: Border.all(
                          color: Colors.black,
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextButton(
                          onPressed: () {
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => ResetPassword()));
                            //action on tap
                          },
                          child: Text(
                            "Forgot Password",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          )),
                    ),
                  ),
                ],
              ),
            )
          ]),
        ),
      )),
    );
  }

  InputDecoration myInputDecoration(
      {required String label, required IconData icon}) {
    return InputDecoration(
      hintText: label, //show label as placeholder
      hintStyle:
          TextStyle(color: Colors.purple[100], fontSize: 20), //hint text style
      prefixIcon: Padding(
          padding: EdgeInsets.only(left: 20, right: 10),
          child: Icon(
            icon,
            color: Colors.purple[100],
          )
          //padding and icon for prefix
          ),

      contentPadding: EdgeInsets.fromLTRB(30, 20, 30, 20),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(
              color: Colors.purple.shade500,
              width: 1)), //default border of input

      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(
              color: Colors.purple.shade500, width: 1)), //focus border

      fillColor: Color.fromRGBO(131, 33, 167, 0.5019607843137255),
      filled: true, //set true if you want to show input background
    );
  }

  Widget errmsg(String text) {
    //error message widget.
    return Container(
      padding: EdgeInsets.all(15.00),
      margin: EdgeInsets.only(bottom: 10.00),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.purple,
          border: Border.all(color: Colors.purple.shade300, width: 2)),
      child: Row(children: <Widget>[
        Container(
          margin: EdgeInsets.only(right: 6.00),
          child: Icon(Icons.info, color: Colors.white),
        ), // icon for error message

        Text(text, style: TextStyle(color: Colors.white, fontSize: 18)),
        //show error message text
      ]),
    );
  }
}
